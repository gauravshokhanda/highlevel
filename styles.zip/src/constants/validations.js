export const  passwordminlength =8;

export const nameminlength = 3; 